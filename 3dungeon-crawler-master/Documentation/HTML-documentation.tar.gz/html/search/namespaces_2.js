var searchData=
[
  ['interfaces',['Interfaces',['../namespaceInterfaces.html',1,'']]]
];
